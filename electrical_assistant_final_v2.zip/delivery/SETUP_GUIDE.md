# 📚 دليل الإعدادات والتثبيت

## ⚙️ المتطلبات الأساسية

- Python 3.8+
- pip (مدير المكتبات)
- API Key من Anthropic

## 🚀 خطوات التثبيت السريع

### 1. **تثبيت المكتبات المطلوبة**

```bash
# عبر requirements.txt
pip install -r requirements.txt

# أو يدويًا
pip install streamlit==1.35.0
pip install pandas==2.1.3
pip install plotly==5.18.0
pip install python-dotenv==1.0.0
pip install anthropic==0.7.11
pip install pyarrow==14.0.1
```

### 2. **إعداد متغيرات البيئة**

#### خطوة أ: نسخ ملف البيئة
```bash
cp .env.example .env
```

#### خطوة ب: تعديل ملف `.env`
```bash
# على macOS/Linux
nano .env

# على Windows
notepad .env
```

#### خطوة ج: أضف مفتاح API الخاص بك
```env
# ====================================
# Electrical Assistant - Configuration
# ====================================

# Anthropic API Configuration
ANTHROPIC_API_KEY=sk-ant-api03-YOUR_KEY_HERE

# Claude Model (استخدم الإصدار الأحدث)
CLAUDE_MODEL=claude-opus-4-1-20250805

# Database Configuration
DATABASE_URL=sqlite:///./electrical_assistant.db

# Streamlit Configuration
STREAMLIT_SERVER_PORT=8501
STREAMLIT_SERVER_HEADLESS=false

# Environment
ENVIRONMENT=development
DEBUG=true

# RAG Configuration
RAG_TOP_K=5
RAG_SIMILARITY_THRESHOLD=0.7

# Report Configuration
REPORT_MAX_PAGES=50
REPORT_EXPORT_FORMAT=pdf
```

### 3. **تشغيل التطبيق**

#### الطريقة الأساسية
```bash
streamlit run app_enhanced_fixed.py
```

#### مع تحديد المنفذ
```bash
streamlit run app_enhanced_fixed.py --server.port 8501
```

#### مع تشغيل في الخلفية (على macOS/Linux)
```bash
nohup streamlit run app_enhanced_fixed.py > streamlit.log 2>&1 &
```

#### مع تشغيل على الإنترنت
```bash
streamlit run app_enhanced_fixed.py --logger.level=debug
```

## 🌐 الوصول إلى التطبيق

بعد التشغيل، سيكون التطبيق متاحاً على:
- **URL**: http://localhost:8501
- **Mobile**: http://your-ip-address:8501

## 🔑 الحصول على مفتاح API

### من Anthropic Console
1. توجه إلى https://console.anthropic.com
2. قم بإنشاء حساب أو تسجيل الدخول
3. اذهب إلى "API Keys" في الإعدادات
4. انسخ مفتاحك وضعه في `.env`

## 🛠️ استكشاف الأخطاء

### المشكلة: "ANTHROPIC_API_KEY غير موجود"
**الحل:**
```bash
# تأكد من وجود ملف .env
ls -la .env

# تأكد من وجود المفتاح فيه
grep ANTHROPIC_API_KEY .env

# جرب إعادة تشغيل التطبيق
```

### المشكلة: "Error 404 - model not found"
**الحل:**
```bash
# تحديث ملف .env باستخدام موديل متاح
CLAUDE_MODEL=claude-opus-4-1-20250805
```

### المشكلة: "Port 8501 already in use"
**الحل:**
```bash
# استخدم منفذ مختلف
streamlit run app_enhanced_fixed.py --server.port 8502

# أو أغلق العملية القديمة
lsof -i :8501  # لعرض العملية
kill -9 PID     # لإيقافها
```

### المشكلة: "Failed to import anthropic"
**الحل:**
```bash
# إعادة تثبيت المكتبة
pip uninstall anthropic
pip install anthropic==0.7.11
```

### المشكلة: "Database is locked"
**الحل:**
```bash
# أغلق جميع نسخ التطبيق
pkill -f "streamlit"

# انتظر 5 ثوان
sleep 5

# أعد التشغيل
streamlit run app_enhanced_fixed.py
```

## 📁 هيكل الملفات

```
electrical_assistant/
├── app_enhanced_fixed.py          # الملف الرئيسي للتطبيق
├── chatbot_rag.py                 # نظام RAG والـ AI Chat
├── db.py                          # إدارة قاعدة البيانات
├── electrical_assistant.db        # قاعدة البيانات (SQLite)
├── .env                           # متغيرات البيئة (خاصة)
├── .env.example                   # مثال على متغيرات البيئة
├── requirements.txt               # المكتبات المطلوبة
├── README.md                      # معلومات عامة
├── IMPROVEMENTS.md                # ملخص التحسينات
└── SETUP_GUIDE.md                # هذا الملف
```

## 🧪 اختبار التطبيق

### اختبار سريع
```bash
# 1. تأكد من التشغيل
curl http://localhost:8501

# 2. جرب صفحة Dashboard
# توجه إلى http://localhost:8501

# 3. جرب AI Chat
# اضغط على AI Chat في الـ sidebar

# 4. جرب إضافة بيانات
# اذهب إلى "إدخال البيانات" وأضف مشروع
```

### اختبار قائمة كاملة
- [ ] تحميل الصفحة الرئيسية
- [ ] التنقل بين الصفحات
- [ ] AI Chat يعمل
- [ ] إضافة مشروع جديد
- [ ] تحميل ملف
- [ ] عرض التقارير
- [ ] على الجوال: الـ navigation يعمل

## 💾 النسخ الاحتياطية

### النسخ اليدوية
```bash
# نسخ قاعدة البيانات
cp electrical_assistant.db electrical_assistant.db.backup

# نسخ جميع البيانات
zip -r backup_$(date +%Y%m%d).zip . --exclude="*.pyc" "*/__pycache__"
```

### استعادة من النسخة الاحتياطية
```bash
# استعادة قاعدة البيانات
cp electrical_assistant.db.backup electrical_assistant.db

# أو استعادة من الـ zip
unzip backup_20260506.zip
```

## 🔐 نصائح الأمان

1. **لا تشارك مفتاح API**: احتفظ به سري
2. **استخدم `.env.example`**: بدلاً من `.env` في الـ version control
3. **أضف `.env` إلى `.gitignore`**:
   ```bash
   echo ".env" >> .gitignore
   ```
4. **تحديثات منتظمة**:
   ```bash
   pip install --upgrade streamlit anthropic
   ```

## 📞 الدعم والمساعدة

إذا واجهت مشاكل:
1. تحقق من سجل الأخطاء في `streamlit.log`
2. تأكد من وجود الإنترنت للاتصال بـ Anthropic API
3. جرب تنظيف الـ cache:
   ```bash
   streamlit cache clear
   ```
4. أعد تشغيل التطبيق من جديد

## 🚀 الخطوات التالية

بعد التثبيت الناجح:
1. استكشف جميع الصفحات
2. جرب AI Chat مع مستندات مختلفة
3. أضف بيانات حقيقية
4. اختبر على أجهزة مختلفة

---

**ملاحظة:** تم اختبار جميع الخطوات على macOS و Linux. على Windows قد تختلف بعض الأوامر قليلاً.
